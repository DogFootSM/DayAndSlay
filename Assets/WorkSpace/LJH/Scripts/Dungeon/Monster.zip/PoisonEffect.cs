using UnityEngine;

public class PoisonEffect : Effect
{
    private float damageCooldown = 1f; // �ʴ� 1�� ������
    private float timer = 0f;

    protected override void Tick()
    {
        if (timer > 0f)
            timer -= Time.deltaTime;
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player") && timer <= 0f)
        {
            Debug.Log("��������");
            timer = damageCooldown;
        }
    }
}
