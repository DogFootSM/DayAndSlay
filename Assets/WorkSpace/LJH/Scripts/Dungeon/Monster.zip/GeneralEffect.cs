public class GeneralEffect : Effect
{
    protected override void Tick() { }
}
