using UnityEngine;

public class IsAttackRangeNode : BTNode
{
    private Transform self;            // ����
    private Transform target;         // �÷��̾�
    private float range;             // ���� �Ÿ�

    public IsAttackRangeNode(Transform self, Transform target, float range)
    {
        this.self = self;
        this.target = target;
        this.range = range;
    }

    public override NodeState Tick()
    {
        float distance = Vector3.Distance(self.position, target.position);
        if (distance <= range)
        {
            return NodeState.Success;
        }

        return NodeState.Failure;
    }
}
