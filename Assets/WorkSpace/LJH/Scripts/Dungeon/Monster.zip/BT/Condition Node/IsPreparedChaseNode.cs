using UnityEngine;

public class IsPreparedChaseNode : BTNode
{
    private Transform self;            // ����
    private Transform target;         // �÷��̾�
    private float chaseRange;             // ���� �Ÿ�
    private float attackRange;      // ���� ��Ÿ�

    public IsPreparedChaseNode(Transform self, Transform target, float chaseRange, float attackRange)
    {
        this.self = self;
        this.target = target;
        this.chaseRange = chaseRange;
        this.attackRange = attackRange;
    }

    public override NodeState Tick()
    {
        float distance = Vector3.Distance(self.position, target.position);

        if (distance <= chaseRange && distance > attackRange)
        {
            return NodeState.Success;
        }

        return NodeState.Failure;
    }
}
