using UnityEngine;

public class IsPreparedAttackNode : BTNode
{
    private Transform self;            // ����
    private Transform target;         // �÷��̾�
    private float range;             // ���� �Ÿ�
    private float cooldown;         // ���� ��ٿ�
    private float currentCooldown; // ���� ��ٿ�

    /// <summary>
    /// 
    /// </summary>
    /// <param name="self">�ڽ�</param>
    /// <param name="target">�÷��̾�</param>
    /// <param name="range">�Ÿ�</param>
    public IsPreparedAttackNode(Transform self, Transform target, float range, float cooldown)
    {
        this.self = self;
        this.target = target;
        this.range = range;
        this.cooldown = cooldown;
        currentCooldown = 0f;
    }

    public override NodeState Tick()
    {
        float distance = Vector3.Distance(self.position, target.position);

        if (currentCooldown > 0f)
            currentCooldown -= Time.deltaTime;


        if (distance <= range && currentCooldown <= 0f)
        {
            currentCooldown = cooldown;
            return NodeState.Success;
        }
        return NodeState.Failure;
    }
}
