using System;

public class IsPreparedCooldownNode : BTNode
{
    private bool canAttack;         // ���� ��ٿ�
    private readonly Func<bool> condition; // ���� ��������Ʈ

    public IsPreparedCooldownNode(Func<bool> condition)
    {
        this.condition = condition;
    }

    public override NodeState Tick()
    {
        if (condition != null && condition())
        {
            return NodeState.Success;
        }
        return NodeState.Failure;
    }
}
