using UnityEngine;

public class EliteOrcMethod : BossMonsterMethod
{
    private BossMonsterAI eliteOrc;
    
    [SerializeField] private GameObject rushEffect;

    private void Start()
    {
        MonsterInit();
    }
    public override void Skill_First()
    {
        //���� ��ų
        SetEffectActiver(rushEffect);
        
    }

    public override void Skill_Second()
    {
    }

}
