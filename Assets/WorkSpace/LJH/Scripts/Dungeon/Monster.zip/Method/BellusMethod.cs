using UnityEngine;

public class BellusMethod : BossMonsterMethod
{
    private BossMonsterAI bellus;
    private BossMonsterAI malus;
    
    [SerializeField] private GameObject bellusHealEffect;
    [SerializeField] private GameObject malusHealEffect;
    [SerializeField] private GameObject poisonWarnigEffect;
    [SerializeField] private GameObject poisonEffect;

    private void Start()
    {
        bellus = GetComponent<Bellus>();
        malus = ((Bellus)bellus).GetPartner();
    }
    public override void Skill_First()
    {
        //�� ��ų
        SetEffectActiver(bellusHealEffect);
        SetEffectActiver(malusHealEffect);
        
        bellus.GetMonsterModel().SetMonsterHp(10);
        malus.GetMonsterModel().SetMonsterHp(10);
    }

    public override void Skill_Second()
    {
        //�� ���� ��ġ
        SetPosEffect(poisonWarnigEffect);
        SetPosEffect(poisonEffect);
        
        SetEffectActiver(poisonWarnigEffect);
        SetEffectActiver(poisonEffect);
    }
    
}

