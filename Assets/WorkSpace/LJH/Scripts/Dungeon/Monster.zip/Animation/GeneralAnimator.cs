using System.Collections;
using System.Collections.Generic;
using AYellowpaper.SerializedCollections;
using UnityEngine;
using UnityEngine.U2D.Animation;

[RequireComponent(typeof(Animator))]
public class GeneralAnimator : MonoBehaviour
{
    protected Animator animator;
    protected SpriteLibrary spriteLibrary;

    [SerializedDictionary("ActionName", "SpriteLibrary")]
    [SerializeField]
    protected SerializedDictionary<string, SpriteLibraryAsset> spriteDict = new SerializedDictionary<string, SpriteLibraryAsset>();

    MonsterStateMachine stateMachine;

    private int currentAnimationHash;

    private bool isAction = false;

    protected Dictionary<Direction, string> moveAction = new Dictionary<Direction, string>();
    protected Dictionary<Direction, string> attackAction = new Dictionary<Direction, string>();
    protected Dictionary<Direction, string> hitAction = new Dictionary<Direction, string>();

    Direction dir;
    GameObject player;

    private Direction attackDir;
    private Direction moveDir;

    float term = 0.1f;

    private void Start()
    {
        animator = GetComponent<Animator>();
        spriteLibrary = GetComponent<SpriteLibrary>();

        stateMachine = new MonsterStateMachine(this);

        stateMachine.ChangeState(new MonsterIdleState());

        DictinaryInit();
        player = GameObject.FindWithTag("Player");

        StartCoroutine(dirCoroutine());
    }


    private void Update()
    {
        if (isAction)
        {
            //�ִϸ��̼� ���൵ Ȯ��
            AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);

            currentAnimationHash = SetAnimationHash(attackAction[SetDirection()]);

            if (stateInfo.fullPathHash == currentAnimationHash && stateInfo.normalizedTime >= 1f)
            {
                isAction = false;
            }

            currentAnimationHash = SetAnimationHash(hitAction[SetDirection()]);
            
            if (stateInfo.fullPathHash == currentAnimationHash && stateInfo.normalizedTime >= 1f)
            {
                isAction = false;
                PlayIdle();
            }
            
        }
        
        
    }

    IEnumerator dirCoroutine()
    {
        //���� �̰� �ǹ� ���� ����
        //because : �ִϸ��̼��� ������ �����ؼ� �� �ִϸ��̼��� ���� ��Ű�� �����̶�
        //���� ��Ų ���Ŀ� ������ �ٲ��ִ°� �ǹ� ����
        while (true)
        {
            yield return new WaitForSeconds(term);
            SetDirection();
        }
    }

    Direction SetDirection()
    {
        //���� ������ ���������� �������
        //���� ��Ȳ�� ó�� �ִϸ��̼� ������ �� ������ �����༭
        //��� �� �������� �̵��ϴ� ����

        Vector2 diff = player.transform.position - transform.position;

        if (Mathf.Abs(diff.x) > Mathf.Abs(diff.y))
        {
            dir = (diff.x > 0) ? Direction.Right : Direction.Left;
        }
        else
        {
            dir = (diff.y > 0) ? Direction.Up : Direction.Down;
        }

        return dir;
    }

    int SetAnimationHash(string currentAnimation)
    {
        return Animator.StringToHash("Base Layer." + currentAnimation);
    }

    public void PlayIdle()
    {
        if (isAction) return;

        spriteLibrary.spriteLibraryAsset = spriteDict["Move"];
        animator.Play("MonsterIdle");

    }
    public void PlayMove()
    {
        if (isAction) return;

        moveDir = SetDirection();
        spriteLibrary.spriteLibraryAsset = spriteDict["Move"];
        animator.Play(moveAction[moveDir]);
    }
    public void PlayAttack()
    {

        if (isAction) return;

        isAction = true;

        attackDir = SetDirection();
        spriteLibrary.spriteLibraryAsset = spriteDict["Attack"];
        animator.Play(attackAction[attackDir]);

    }
    public void PlayHit()
    {
        if (isAction) return;

        isAction = true;

        spriteLibrary.spriteLibraryAsset = spriteDict["Hit"];
        animator.Play(hitAction[SetDirection()]);
    }
    public void PlayDie()
    {
        Debug.Log("���� �ִϸ��̼� �����");
        spriteLibrary.spriteLibraryAsset = spriteDict["Die"];
        animator.Play("MonsterDie");
    }

    void DictinaryInit()
    {
        moveAction.Add(Direction.Left, "MonsterMoveLeft");
        moveAction.Add(Direction.Right, "MonsterMoveRight");
        moveAction.Add(Direction.Up, "MonsterMoveUp");
        moveAction.Add(Direction.Down, "MonsterMoveDown");

        attackAction.Add(Direction.Left, "MonsterAttackLeft");
        attackAction.Add(Direction.Right, "MonsterAttackRight");
        attackAction.Add(Direction.Up, "MonsterAttackUp");
        attackAction.Add(Direction.Down, "MonsterAttackDown");

        hitAction.Add(Direction.Left, "MonsterHitLeft");
        hitAction.Add(Direction.Right, "MonsterHitRight");
        hitAction.Add(Direction.Up, "MonsterHitUp");
        hitAction.Add(Direction.Down, "MonsterHitDown");
    }

}
