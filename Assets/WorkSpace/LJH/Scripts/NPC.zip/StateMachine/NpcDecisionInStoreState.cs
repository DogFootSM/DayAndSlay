using UnityEngine;

/// <summary>
/// ���� ���ο��� �ൿ�� �����ϴ� ����
/// </summary>
public class NpcDecisionInStoreState : INpcState
{
    StoreManager store;
    private Npc npc;
    TargetSensorInNpc targetSensor;

    public NpcDecisionInStoreState(Npc npc, StoreManager store, TargetSensorInNpc targetSensor)
    {
        this.npc = npc;
        this.store = store;
        this.targetSensor = targetSensor;
    }

    public void Enter()
    {
        if (npc == store.PeekInNpcQue())
        {
            //ī���ͷ� �̵�
            Vector3 deskPos = targetSensor.GetDeskPosition();
            npc.StateMachine.ChangeState(new NpcMoveState(npc, deskPos, new WaitForPlayerState(npc)));

        }
        else
        {
            // ���� ���������� �̵�
            Vector3 randomPos = targetSensor.GetRandomPositionInStore();
            npc.StateMachine.ChangeState(new NpcMoveState(npc, randomPos, new NpcDecisionInStoreState(npc, store, targetSensor)));
        }
    }

    public void Update() 
    {
    }
    public void Exit() { }
}
