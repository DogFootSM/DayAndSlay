using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Npc ��Ȱ��ȭ
/// </summary>
public class NpcGoneState : INpcState
{
    private Npc npc;

    public NpcGoneState(Npc npc)
    {
        this.npc = npc;
    }
    public void Enter()
    {
        npc.StopMove();
        npc.NpcGone();
    }

    public void Update()
    {
    }

    public void Exit()
    {

    }

}
