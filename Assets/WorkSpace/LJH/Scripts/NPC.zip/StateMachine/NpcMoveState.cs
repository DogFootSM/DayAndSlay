using UnityEngine;

/// <summary>
/// NPC �̵� ����
/// </summary>
public class NpcMoveState : INpcState
{
    private Npc npc;
    private Vector3 target;
    private INpcState nextState;

    public NpcMoveState(Npc npc, Vector3 target, INpcState nextState = null)
    {
        this.npc = npc;
        this.target = target;
        this.nextState = nextState ?? new NpcIdleState(npc); // �⺻��
    }

    public void Enter()
    {
        //�ʱ�ȭ
        npc.StopMove();
        npc.UpdateGrid();
        
        npc.MoveTo(target, () =>
        {
            if (npc.StateMachine.CurrentState == this)
            {
                npc.StateMachine.ChangeState(nextState);
            }
        });

    }

    public void Update()
    {
        if (npc.StateMachine.CurrentState != this)
            return;


        if (npc.ArrivedDesk() && npc.GetStoreManager().PeekInNpcQue() == npc)
        {
            npc.StateMachine.ChangeState(new WaitForPlayerState(npc));
        }
    }

    public void Exit()
    {
        npc.StopMove();
    }
}
