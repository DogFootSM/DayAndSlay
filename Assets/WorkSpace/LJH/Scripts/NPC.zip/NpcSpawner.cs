using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;
using Zenject;

public class NpcSpawner : MonoBehaviour
{
    [Inject]
    DiContainer container;
    private Vector3 npcSpawnPos;

    [Header("NPC�� ������ ������ ���� �ְ� �¾�� Ȯ�� 1 / npcBuyProbability")]
    [SerializeField] float npcBuyProbability = 3f;

    private float npcSpawnDelay = 5f;
    private WaitForSeconds delayTime;

    [Inject]
    private List<Npc> npcPreset = new List<Npc>();
    private List<Npc> npcList = new List<Npc>();
    void Start()
    {
        Init();

        StartCoroutine(NpcSpawnCoroutine());
    }

    IEnumerator NpcSpawnCoroutine()
    {
        //���ɶ����� ����� ���������
        while (DayManager.instance.dayOrNight == DayAndNight.DAY)
        {
            yield return delayTime;

            int npcIndex = Random.Range(0, npcPreset.Count);
            npcList.Add(container.InstantiatePrefabForComponent<Npc>(npcPreset[npcIndex], npcSpawnPos, Quaternion.identity,null));
            
            Npc npc = npcList[npcList.Count - 1];
            
            //npc�� Ÿ�� ����
            //GenderType gender = (GenderType)Random.Range(0, 2);
            //AgeType age = (AgeType)Random.Range(0, 3);
            //npc.SetNpcType(gender, age);
            
            //npc�� ���̾� y/n ����
            npc.IsBuyer = Random.value < 1f / npcBuyProbability;
            npc.name = npc.name.Replace("(Clone)", "");
        }
    }

    void Init()
    {
        npcSpawnPos = transform.position;

        delayTime = new WaitForSeconds(npcSpawnDelay);
    }
    
}
